/*
 * @author Max Ghislain
 * @version August 25,2022
 * 
 * Library of math methods
 */
public class Calculate {
	//Part 1
	public static int square(int n) { //returns square of input
		return(n*n);
	}
	
	public static int cube(int n) { //returns cube of input
		return(n*n*n);
	}
	
	public static double average(double n, double m) { // returns average of two inputs
		return((n+m)/2);
	}
	
	public static double average(double n, double m, double o) { // returns the average of three inputs
		return((n+m+o)/3);
	}
	
	public static double toDegrees(double radians) { // returns radians as degrees
		return(radians * 180/3.14159); //pi radians = 180 degrees, 1 radian = 180/pi degrees, 6 = (3)2
	}
	
	public static double toRadians(double degrees) {
		return(degrees * 3.14159/180);
	}
	
	public static double discriminant(double a, double b, double c) {
		return(b*b-4*a*c);
	}
	
	public static String toImproperFrac(int wholeNum, int numerator, int denominator) {
		
		return(wholeNum * denominator+numerator+"/"+ denominator);
	}
	
	public static String toMixedNum(int numerator, int denominator) {
		int remainder = numerator % denominator;
		if(remainder == 0) {
			return(numerator+"/"+denominator);
		}
		int wholeNumber = (numerator-remainder)/denominator;
		
		return(wholeNumber+"_"+remainder+"/"+denominator);
	}
	
	public static String foil(int a, int b, int c, int d, String var) {
		/*
		 * (ax+b)(cx+d) => ax^2+bx+c
		 * = ax*cx + ax*d + b*cx + b*d
		 * = a*c*(x^2) + (a*d+b*c)*(x) + b*d
		 * 
		 */
		
		return(a*c+var+"^2 + "+(a*d+b*c)+var+" + " + b*d);
	}
	
	//Part 2
	public static boolean isDivisibleBy(int a, int b) {
		if(a%b == 0) {
			return true;
		}
		return false;
	}
	
	public static double absValue(double num) {
		if(num < 0) {
			return num*-1;
		}
		return num;
	}
	
	public static double max(double a, double b) {
		if(a>b) {
			return a;
		}
		return b;
	}
	
	public static double max(double a, double b, double c) { //eeehhhh
		if(a>b) {
			if(a>c) {
				return a;
			} else {
				return c;
			}
		} else if(b>c) {
			return b;
		} else {
			return c;
		}
	}
	
	public static int min(int a, int b) {
		if(a<b) {
			return a;
		}
		return b;
	}
	
	public static double round2(double a) {
		int intNum = (int)(a*100);
		double doubleNum = a*100;
		double decimal = doubleNum-intNum;
		if(decimal>=0.5) {
			return (double)(intNum+1)/100;
		}
		return (double)intNum/100;
		// 1.11 -> 111, 1.116 -> 111.6 = 
		//(double)((int)(a*100))/100;
	}
	
	//Part 3
	public static double exponent(double x, int n) {
		while(n>1) {
			x*=x;
			n--;
		}
		return x;
	}
	
	public static int factorial(int n) {
		int ans = n;
		while(n>1) {
			ans*=(n-1);
			n--;
		}
		return ans;
	}
	
	public static boolean isPrime(int n) {
		if(n>1) {
			//n%2, n%3, n%5
			for(int i=2;i!=n;i++) {
				for(int j=2;j!=n;j++) {
					if(i*j==n) {
						return true;
					}
				}
			}
		}
		
		return false;
	}
	
	
}
